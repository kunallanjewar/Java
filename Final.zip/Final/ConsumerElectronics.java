
public class ConsumerElectronics 
{
	public static void main(String[] args) 
	
	{
		Computer One = new Computer("HP", 450, 12.5, true);
		System.out.println (One);
		
		Cellphone Two = new Cellphone("Samsung", 99.99 , 0.15 , "555-987-1829");
		System.out.println (Two);
	}
}